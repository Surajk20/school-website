<!DOCTYPE html>
<html lang="en">
<body>

<img src="data1/images/ground2.jpg" width="250" height="250"  align="left">
<p>This school was a dream to us a few years ago, for we used to look around us and find ourselves frozen in our position and bewildered.</p>
<p>school helps  child to learn ho to live in society with other people, ow to be responsive and bejave with others, ho to respect their elders especially the teachers. they transform a child from normal being into human being.</P>
<p>GOD, however, has eased the path and erased the obstacles which blocked our way. It is not of importance that we build institutes and celebrate their inauguration. The important thing is that we exert all our efforts to benefit from such institutes, to realize what our nation expects from us.The School is the first stage where a child learn to become a civilized human being. School is like a temple of knowledge where we are trained for social and professional life.</p>
<p>Our School has excellent facilities like a computer lab, science labs, library and the sports ground. There are strict ules and regulations for everything which all have to follow on regular basis. The atmosphere of our school is amazing. it is surrounded by trees and beatiful flowers. our School conducts frequent sports activites, competitions, debates and goup discussions on a regular basis. Teachers not only teach us the regular subjects but also take a session on cleanliness, health and moral values.</p>















	</body>
	</html>
