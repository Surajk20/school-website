School-Website-PHP
==================

This is a School Website created using PHP and contains a database to hold reords.This project is a complete website developed using BootStrap. Database is MYSQL. HTML,CSS,Javascript and JQuery are used in client side and PHP at server side. Facebook APP has been linked with it for others to like and share this website on their Facebook.
This Website includes a RSS News Feed which is created at rapidfeeds and the xml is being read at the webite page.
Ajax protocol is being used at many stages in developing this site. The Registration and Login details are being stored in a database server.
PHP is used at server side to coordinate with database. Cookies are being set to keep record of last visit through PHP.
Hosting domain is hostingsiteforfree
Website available at : http://www.msuhail.hostingsiteforfree.com/project_php/

Skills: HTML,CSS,JavaScript,JQuery,PHP,MYSQL,AJAX,RSS(XML),Facebook API
Tools: Bootstrap

To set database connection to localhost
change servername,username,password,database name in login.php and registration.php


