         
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
 </head>
 <body>
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js">
	
	</script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>



<img src="data1/gallery/img10.jpg" vspace="10" height="300" width="800">
<img src="data1/gallery/img4.jpg"  height="250" width="395" hspace="5">
<img src="data1/gallery/img7.jpg" height="250" width="395">

<img src="data1/gallery/img5.jpg"  height="250" width="395" hspace="5" vspace="10">
<img src="data1/gallery/img3.jpg" height="250" width="395" vspace="10">

<img src="data1/gallery/img9.jpg"  height="250" width="395" hspace="5">
<img src="data1/gallery/img11.jpg" height="250" width="395">

<img src="data1/gallery/img13.jpg"  height="250" width="395" hspace="5" vspace="10">
<img src="data1/gallery/img2.jpg" height="250" width="395" vspace="10">

</body>
</html>